# common-api-framework-and-api-template
Provides a starting point for developers to start creating MuleSoft projects. More information on the usage can be found at https://wiki.corp.mulesoft.com/display/SVCS/Common+API+Framework+and+API+Template
